# Hide & Sausage - browser version of main.py, made by tools/build_web.py
import asyncio

import pygame          # pygbag only loads pygame if main.py imports it

from hide_and_sausage.ui.app import App
from hide_and_sausage.ui.scenes_menu import TitleScene


# main - opens the game and starts on the title screen.
async def main():
    app = App()
    await app.run(TitleScene(app))


asyncio.run(main())
